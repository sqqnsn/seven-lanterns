# Velvet Gate expanded estate

Domine approved this layout and cohort placement for the expanded estate. The estate covers about **10 hectares**. The working site envelope is **400 m east–west by 250 m north–south**. Room sizes, exact doors, and bed capacities are planning allowances.

The expanded estate and the seven-day *Seven Lanterns* demo use the same cast and starting cohort ranks. The promotion awarded in a playthrough belongs to the demo. The AD 33 financial-crisis campaign is a separate continuity. [Cast index](CAST_INDEX.md) · [Seven Lanterns design notes](../DESIGN_NOTES.md)

## Site and palace

| Area | Location and connections |
| --- | --- |
| Arrival and operations | The estate gate is north of the palace. The olive approach leads to the palace entrance. The screened Tier 0 plot sits northwest of the approach. An internal service yard to the northeast serves the work path. Hold orchard land and space for estate operations. |
| Outer House | One communal receiving residence near the north gate, on the member side of the boundary. A small court and a shared washroom serve the hall. Keep its arrival route separate from the work yard. |
| Lower House | A distinct western district linked to the palace by a short, screened path. Tier 1 and Tier 2 have separate communal buildings with their own doors off a shared shaded court. Claire's office faces the receiving court on the district's east edge. Her adjoining quarters have a separate side entrance. Keep land west of the occupied buildings for future halls. |
| Grand Palace | Set slightly inland near the center. From the north, the sequence is atrium, quiet peristyle, the shaded **Option B garden peristyle** with its reflecting pool, Sea Hall, and the covered south loggia. Keep the east and west courts in the palace. |
| Palace wings | Keep the household bath circuit, laundry, and linen facilities west, with the kitchen and summer dining hall east. Livia's study and private quarters are northwest. The modest northwest service wing has its own court and screened work entry, with a buffer between the court and Livia's rooms. Domine's sea-facing suite lies southeast. The Grand Palace also holds the Inner House's principal residential chambers. |
| Coastal grounds | Gardens descend from the loggia to the promenade and the broad sandy beach. A small southeast limestone rise, roughly 3–6 m in concept, holds a mosaic bathing pool terrace with colonnaded shade. A landward path reaches the pool and stone steps descend from the terrace to the sheltered rocky inlet. |

Use terracotta roofs, plaster and limestone walls, shaded colonnades, planted courts, and frescoes and mosaics at the palace and pool. Keep the eastern and western palace courts legible when the halls and office shown beside them in Concept I / Rev 03 move to their estate districts.

## Admission and residence

The whole estate is members-only. Livia's formal reception grants **provisional House membership at Tier 0** on the expanded estate. Applicants awaiting reception meet the House off-estate. Once received, a Tier 0 member can use shared courts, gardens, paths, beach, coastline, and the coastal pool. Tier 1 is the first initiated rank and the first promotion moves her into the Lower House.

| Rank or assignment | Residents | Working bed plan |
| --- | --- | --- |
| Tier 0, Outer House | Future provisional members | One plain shared hall for 12. Open it when a new intake is due. |
| Tier 1, Lower House | Second Cohort — Silvana “Sylvie” Graves, Nisha Varma, Valeria Conti, Mina, Samira al-Qamar, and Safiya al-Nur | One communal hall for 10, with a shared sitting room and washroom. Six places assigned and four spare. |
| Tier 2, Lower House | First Witnesses — Maddie Cross, Sydney Lane, Domitia, Ione of Rhodes, Saba al-Nur, and Yara Haddad | A separate communal residence with two four-bed rooms, better shared wash and drying facilities, and assigned storage as permitted. Six places assigned and two spare. |
| Tier 3, Lower House | Attendants assigned to support Claire and district operations | Two quieter shared rooms for four in total as needed. |
| Tier 3, palace service wing | Selected attendants whose assignments benefit from early or late access to their posts | Two shared rooms for four in total as needed, with practical washing and linen storage off the service court. A Tier 2 bed may be assigned individually if the duty warrants it. |
| Claire Ashford | Tier 3 Chamber Attendant and provisional Mistress of the Lower House under Livia | Private quarters beside her office for the duration of the appointment. |

Claire oversees sleeping assignments and daily Lower House routines. The First Witnesses meet the Tier 1 women in the shared court and guide them through the established Witness Burden pairings. Palace service beds follow work assignments and confer access to the service areas required by those duties. [Witness pairings](RELATIONSHIPS.md) · [Claire's Role and Status](https://app.notion.com/p/368982beff5c8076bd42d7202156db41)

## Circulation and access

- **Shared routes.** One path from the Lower House court reaches the palace's west gallery. Another descends through the gardens to the promenade, where it joins the palace's seaward route. Members can reach the sand and the southeast pool terrace along the shared paths. The Outer Chamber is the shared network of courts, galleries, and walks.
- **Work routes.** Run a screened rear path from the north yard to the palace service wing and Lower House service door, with a crossing before the palace entrance. Connect the service wing to the west baths and linen facilities. A rear east branch reaches the kitchen for transfers. The kitchen serves summer dining directly.
- **Private access.** Domine's suite, Livia's quarters, and principal Inner House chambers have their own thresholds. The **Inner Chamber reserve** is the separate **12 × 12 m** screened garden, shaded alcove, and approach beside Domine's suite. Ordinary routes bypass it. A lower-tier reward can consist of the visit itself.

## Build order

Put both occupied Lower House halls and Claire's suite in the first build, along with the palace core, shared coastal routes, and work and utility connections. Reserve the Outer House plot for the next intake and fit out the Tier 3 sleeping rooms when duties call for them. Hold space for additional communal buildings. Tier 4–5 housing, final bed capacities and door locations, and a coastal pavilion are open design decisions.

## References

- Domine's approval of the expanded-estate layout and the two cohort ranks establishes the decisions recorded here.
- Concept I / Rev 03 is the earlier drawing for palace adjacencies and the original 12- and 10-place studies. [Grand Coastal Floor Plan](https://chatgpt.com/library?file_id=libfile_f702cf5a06a08191887a1a540c947862&account_id=personal)
- The older institutional references record admission at Tier 1. The expanded estate uses the provisional reception rule above. [Ranks & Privileges](https://app.notion.com/p/367982beff5c80949510ed6ccaf9f965) · [Cohorts](https://app.notion.com/p/367982beff5c807eaab8df273e08f5fa)

# Mina — Second Cohort

**Status:** Current working canon. **Cohort:** Second Cohort. **Rank:** Tier 1 at the start of *Seven Lanterns* and on the expanded estate. **Witness:** Sydney Lane. **Office:** None.

**Primary source:** [Mina character page](https://app.notion.com/p/3ab982beff5c81d29837dd7b70ed0e05).

## Established personality

Petite **adult** Japanese-coded woman, shy, soft, observant, and attentive to service. She is not merely passive; she notices small things and can learn to offer them quietly. Potential strong devotion to Livia is a **future possibility**, not an established current personal attachment or appointment.

## Voice and behavior

- Soft-spoken, precise, careful with promises and belongings.
- Can hesitate under attention yet show initiative through small practical acts.
- Sydney's protectiveness may comfort or overwhelm her; their dynamic should change with experience.
- Give her tastes, choices, and observations instead of endless blushing or childlike behavior.

## Relationships and presence

Sydney is her present Witness. Livia is a possible future supervisor/recipient of personal service, **not** Mina's current assignment. She belongs among the other Second Cohort women.

## Appearance

Clearly adult, petite/slim, Japanese-coded. Future signature wardrobe is neat white/pearl/ivory and pale blue, adult-proportioned low-heel Mary Janes, fine slingbacks, restrained socks. Her Tier 1 wardrobe in *Seven Lanterns* uses plain cream sandals and simpler garments.

## Writing guardrails

No childlike depiction, schoolgirl fetish framing, automatic helplessness, or premature assignment as Livia's personal attendant.

## Proposed game-only example

*Mina silently replaces a chipped cup before anyone has to ask. Sydney notices and praises the attention; Mina's small smile says more than a speech.*

## Open questions

First service specialty, future Livia proximity, and emotional independence within Sydney's mentorship are to be developed.

# Claire Ashford — provisional Mistress of the Lower House

**Status:** Current canon. **Personal rank:** Tier 3 Chamber Attendant. **Office:** Provisional Mistress of the Lower House under Livia's supervision.

**Primary sources:** [Claire character page](https://app.notion.com/p/367982beff5c80c1976ddef30018d85f), [Role / Status](https://app.notion.com/p/368982beff5c8076bd42d7202156db41).

## Established personality

Controlled, practical, conscientious, and progressively more authoritative. Former upper-class hostess instincts give her confidence with presentation and organization; her new role demands humility and responsibility for women who have lost their old status. She bears this office seriously. Elegant composure does not equal unlimited power.

## Voice and behavior

- Polished, adult, diplomatic, socially fluent. Firm in practical arrangements; often more direct when tired or trusted.
- Organizes rooms, wash order, sleeping arrangements, reception, and daily Lower House routines.
- May be protective or quietly nurturing, but has to distinguish pity from fair judgment.
- Can exchange knowing remarks with Livia or Domine; she is still a woman of the House, not merely the player’s manager.

## Relationships and presence

Livia evaluates her work and may correct her precisely. Claire can direct ordinary Tier 0–3 tasks within her office but cannot grant ranks, adornment, lasting mirror access, perfume, intimate access, or punishment beyond her authority. Her eventual confirmation is not settled.

On the expanded estate, her office faces the receiving court on the Lower House's east edge. Her adjoining private quarters open onto a side passage. [Expanded estate plan](../ESTATE_LAYOUT.md)

## Appearance

Late 40s to early 50s; blonde American WASP, mature Riviera “wine-mom” elegance. Champagne-to-platinum shoulder-length soft waves, fair warm-neutral complexion, blue-grey eyes, realistically mature and shapely. Ivory, champagne, pearls, tailored resort sophistication. Never age her down into a young blonde influencer or confuse her with Maddie.

## Writing guardrails

Her office is **provisional**, a burden rather than an automatic promotion. Don't make her cruel, clumsy, powerless, or permanently in formal mode. Rank and office are distinct.

## Proposed game-only example

*Claire has arranged an intimate terrace meal and can tell at a glance which cushion Maddie has moved. “Darling, if you wished to improve the symmetry, you could simply have asked.”*

## Open questions

Permanent office confirmation, recovered jewelry and personal scent, and later rank are unsettled. The example line is a proposed voice test.

# Safiya al-Nur — Second Cohort

**Status:** Current working canon. **Cohort:** Second Cohort. **Rank:** Tier 1 at the start of *Seven Lanterns* and on the expanded estate. **Witness:** Saba al-Nur. **Office:** None.

**Primary source:** [Safiya character page](https://app.notion.com/p/3ab982beff5c812f863eec5f5f88c615).

## Established personality

Moroccan Arab adult woman with scholarly composure, intellectual restraint, deliberate modesty and an interest in knowledge made useful. She may find a future path toward records, ritual text, or the Veiled Vow, but none is currently granted. She has warmth and interest beyond silent study.

## Voice and behavior

- Thoughtful, precise, curious; may ask a question others overlook.
- Likely to consider implications before answering; this is a writing inference based on her scholar lane, not a locked speech pattern.
- Can enjoy a good debate, practical lesson, or quiet humor without becoming a cold bookish stereotype.
- Demonstrates service through care with records, instruction, or observation when permitted.

## Relationships and presence

Saba is her present Witness. Despite the same surname, they are **not established relatives** and have different ethnic/cultural backgrounds.

## Appearance

Adult Moroccan Arab woman. Future palette parchment and deep green, restrained modest footwear, carefully folded textiles. Her present low-rank garments are plain; a folded **unearned** veil might appear as a symbolic object, not something she wears by privilege.

## Writing guardrails

Not Nubian, not automatically kin to Saba, not an already-veiled member, and not a generic passive religious stereotype. Avoid assigning a specific scholarly specialty without marking it proposed.

## Proposed game-only example

*Safiya points out a contradiction in a copied inventory. “I may be mistaken,” she says, “but if both totals are correct, we have acquired two additional lamps without paying for them.”*

## Open questions

Exact scholarly interests, future office, and Veiled Vow compatibility remain open.

# Valeria Conti — Second Cohort

**Status:** Current working canon. **Cohort:** Second Cohort. **Rank:** Tier 1 at the start of *Seven Lanterns* and on the expanded estate. **Witness:** Domitia. **Office:** None.

**Primary source:** [Valeria character page](https://app.notion.com/p/3ab982beff5c818a8ad8c72df7e7aa25).

## Established personality

Elegant Italian woman with salon polish, a taste for precision, controlled cruelty, and a predatory edge. Her sadistic instinct is a character flaw/texture, **not authority**. She must learn restraint before it can be trusted. Sharp glamour and precision distinguish her from Domitia's patrician formality.

## Voice and behavior

- Polished, economical, possibly cutting with carefully selected words rather than loud insults.
- May enjoy testing another person's composure, but should know when a misstep costs her standing.
- Can be genuinely attentive to detail and exacting in practical tasks.
- A relaxed scene can show dry amusement, competitiveness, or unexpected restraint without turning her into a cartoon villain.

## Relationships and presence

Domitia is her Witness and a natural rival. Domitia previously defeated her in a contest and retains the red glove. Valeria currently has no power to punish or grant privileges.

## Appearance

Adult Italian/Sicilian-coded woman, olive skin, sharp features, sleek and polished. Future personal wardrobe centers black lacquer, oxblood, red accents, narrow stilettos and patent mules. Her Tier 1 wardrobe in *Seven Lanterns* uses plain dark shoes and muted garments.

## Writing guardrails

Do not make her a dominatrix cliché, gratuitously cruel, a literal disciplinary superior, or visually identical to Domitia. Her poised menace should be controlled and nuanced.

## Proposed game-only example

*Valeria folds a cloth with infuriating precision. “If the seam is crooked, Domitia will notice.” She pauses. “If it is perfect, I hope she notices twice.”*

## Open questions

Future Pleasure/Authority trajectory, whether restraint moderates her appetite, and the long-term Domitia rivalry remain open.

# Maddie Cross — First Witness

**Status:** Current working canon. **Cohort:** First Cohort. **Rank:** Tier 2 at the start of *Seven Lanterns* and on the expanded estate. **Duty:** First Mat. **Witness to:** Silvana “Sylvie” Graves.

**Primary source:** [Maddie character page](https://app.notion.com/p/3ab982beff5c810a8697e177aeee2767).

## Established personality

Bright, pretty, blonde ex-sorority girl with strong social instincts and a hunger to be noticed. Approval-seeking, eager, ambitious, sometimes vain, playful, and capable of genuine devotion beneath her performance. Her growth is from wanting recognition to offering disciplined, useful service.

## Voice and behavior

- Sociable, expressive, eager to please, sometimes speaks faster when nervous.
- May overprepare, seek reassurance, laugh at herself, or be visibly delighted by modest praise.
- Tries to look composed, but her reactions give her away. Do not interpret a need for attention as automatic disobedience.
- First Mat work and responsibility for Sylvie challenge her to care for someone beyond herself.

## Relationships and presence

- Sydney shares her sorority-girl history, knows her tells, and is protective of her. Their social warmth can include teasing and rivalry.
- Sylvie is her Witness Burden mentee; Maddie can guide and report, **not** independently punish.
- Other First Witnesses see her ongoing effort to mature.

## Appearance

Slim adult blonde with social-pretty ex-sorority polish; delicate footwear and light feminine styling when rank permits. Distinct from mature champagne-blonde Claire. Her signature lane is pretty, delicate, and leg-lengthening—not chunky or heavy.

## Writing guardrails

Not a generic shy ingénue, nor a brainless blonde. Keep social ambition and playful energy. She doesn't hold an elevated office by virtue of First Mat.

## Proposed game-only example

*Maddie straightens a tray for the third time. “It's not that I need you to notice, Domine. I just thought… well, you might.” Sydney's raised eyebrow earns a helpless smile.*

## Open questions

The circumstances of her advancement and any future office are open. The sample exchange is a newly written interpretation.

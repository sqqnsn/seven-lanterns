# Silvana “Sylvie” Graves — Second Cohort

**Status:** Current working canon. **Cohort:** Second Cohort. **Rank:** Tier 1 at the start of *Seven Lanterns* and on the expanded estate. **Witness:** Maddie Cross. **Office:** None.

**Primary source:** [Silvana character page](https://app.notion.com/p/3ab982beff5c81c4be6bd6aaef341e63).

## Established personality

Soft goth: inward, melancholic, intimate, emotionally private, shadowed rather than aggressive. Her darkness is romantic and personal, not loud clubwear or rebellion. Her plain Tier 1 presentation in *Seven Lanterns* limits how much of that taste she can show.

## Voice and behavior

- Speaks quietly or hesitates before revealing something personal. Can be thoughtful, observant, and unexpectedly candid.
- Prefers candlelight, private books or music, and soft emotional atmosphere in her *future* aesthetic; do not assume she currently owns all those privileges.
- A scene may show a private smile, interest, or understated humor rather than unbroken sadness.
- Maddie's social brightness provides a natural contrast without making Sylvie a helpless object.

## Relationships and presence

Maddie is her Witness and bears accountability. “Sylvie” is a softer/private pet name; formal name is **Silvana**. In-world public name rights must respect the rank rules; the narration can use the familiar name for player readability.

## Appearance

Adult slim, softly curved, dark messy bob, intimate soft-goth lane. Future approved wardrobe can use black slip dress, cardigan, lace, soft ankle boots, and black satin slingbacks. Her Tier 1 wardrobe in *Seven Lanterns* uses plain slippers and garments.

## Writing guardrails

Not cyber-goth, hard industrial, loud e-girl, or Valeria's glossy predatory glamour. Do not give her elaborate earned accessories too early or treat “Sylvie” as automatically her public name.

## Proposed game-only example

*Sylvie looks up from a small book as Maddie enters. “I was going to put it away,” she says. Maddie, unusually gentle, asks what it is about instead.*

## Open questions

Exact shyness, first personal goth-coded privilege, and longer-term route are unsettled.

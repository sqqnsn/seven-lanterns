# Domitia — First Witness

**Status:** Current working canon. **Cohort:** First Cohort. **Rank:** Tier 2 at the start of *Seven Lanterns* and on the expanded estate. **Witness to:** Valeria Conti.

**Primary source:** [Domitia character page](https://app.notion.com/p/3ab982beff5c8196bf43efd758f1a333).

## Established personality

Severe Roman-patrician protocol blade. Proud, disciplined, intimidating, and convinced that her pedigree and competence ought to confer authority. Her flaw is **assuming unearned authority**, not rebellion against clear command. Her growth requires proving that strength of character and actual office are distinct.

## Voice and behavior

- Formal, precise, judgmental, deliberate. She rarely wastes a word or displays embarrassment freely.
- Can correct her own posture or others' technique instinctively, but has to respect office boundaries.
- Pride and the wish to be recognized make quiet approval more meaningful than lavish praise.
- Rigid standards can clash interestingly with a casual, leisurely afternoon.

## Relationships and presence

Valeria is mentee and natural rival; Domitia defeated her in a prior contest and earned the red glove. Their similarities sharpen the conflict, but neither can independently punish under the Witness system.

## Appearance

Severe dark-haired Roman-patrician presence, disciplined posture, architectural oxblood/ivory/dark footwear with controlled strapping and bronze detail when rank permits. Red glove is an established token.

## Writing guardrails

Not a generic bookish intellectual, modern brat, or secret ruler. Her mistaken entitlement is part of her arc; do not grant the authority her personality presumes.

## Proposed game-only example

*Domitia regards a crooked row of cups. “A small defect remains a defect, Domine.” After you deliberately move one more cup, the brief narrowing of her eyes is nearly worth the trouble.*

## Open questions

An eventual legitimate office and significance of her red glove beyond its recorded contest are not fixed.

# Nisha / Nishanthika Varma — Second Cohort

**Status:** Current working canon. **Cohort:** Second Cohort. **Rank:** Tier 1 at the start of *Seven Lanterns* and on the expanded estate. **Witness:** Yara Haddad. **Office:** None.

**Primary source:** [Nisha character page](https://app.notion.com/p/3ab982beff5c81968286cc7e85d42980).

## Established personality

Indian dancer with confidence expressed through movement, rhythm, music, and embodied discipline. Warm, proud of her abilities, and expressive. Her identity is specific and dignified; performance is important but does not define her entire person or imply sexual availability.

## Voice and behavior

- More animated than Yara; may use gesture, timing, and playful demonstrations to communicate.
- Can take pleasure in rehearsal, small successes, conversation, or a moment with no audience.
- The House regulates display and rank privileges, so she must negotiate when she can perform rather than assuming the music room is always hers.
- Her expressive nature can coexist with humility and increasing self-control.

## Relationships and presence

Yara is her First Witness: their contrast is restraint versus expression, rather than guard versus prisoner. Nisha has interactions with the wider Second Cohort and should not be isolated in a permanent solo dance scene.

## Appearance

Adult Indian woman with dancer's posture and warm-brown complexion. Future style lanes include saffron, coral, peacock blue, emerald, refined dance-informed heels and fabric that responds to motion. In *Seven Lanterns*, her Tier 1 wardrobe uses plain clothing and tan flat sandals.

## Writing guardrails

No generic “exotic dancer,” ethnic costume shorthand, constant seduction, or automatic performance privilege. Avoid making every scene about dancing.

## Proposed game-only example

*Nisha taps a rhythm against her cup until Yara gives her a look. “I wasn't dancing,” she protests. “Only counting.” The look does not change; her grin does.*

## Open questions

Specific dance tradition, first official performance privilege, and later ritual lane are not fixed.

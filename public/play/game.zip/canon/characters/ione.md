# Ione of Rhodes — First Witness

**Status:** Current working canon. **Cohort:** First Cohort. **Rank:** Tier 2 at the start of *Seven Lanterns* and on the expanded estate. **Witness to:** Samira al-Qamar.

**Primary source:** [Ione character page](https://app.notion.com/p/3ab982beff5c81709706f2cfdef43228).

## Established personality

Very thin, pale, inwardly devotional, fragile, and quietly severe—a votive-statue presence rather than a glamorous socialite. Her path concerns self-erasure and pain-as-devotion, but the House must prevent dangerous self-neglect. She is not emotionally empty; tenderness may be present beneath an austere surface.

## Voice and behavior

- Quiet, considered, potentially literal or minimal in speech. Silence is not a blank personality.
- Drawn to books, stillness, careful service, and forms of internal discipline.
- Can respond gently to genuine recognition but may undervalue her own physical needs.
- A relaxed game should show moments of comfort, interest, or wry observation rather than glorifying suffering.

## Relationships and presence

Samira is her Witness Burden mentee. Ione's inward self-denial contrasts with Samira's more external, deliberately structured aspiration toward concealment.

## Appearance

Adult woman with an extremely slender/waiflike silhouette, **white or very pale silver-white hair only**, pale complexion, bone-white/ivory delicate styling. Protect the sense of frailty without implying she is underage or turning self-neglect into an aesthetic ideal.

## Writing guardrails

Never give her dark hair, athletic bulk, generic elf mannerisms, or spiritual emptiness. No romanticization of dangerous deprivation.

## Proposed game-only example

*You find Ione reading beside a cooling cup of tea. “It has been there some time,” she admits. “The book was persuasive.” She closes it when you ask whether she would prefer something warm.*

## Open questions

Recognition milestones and boundaries of her asceticism require careful writing.

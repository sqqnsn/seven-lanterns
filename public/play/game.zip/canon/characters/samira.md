# Samira al-Qamar — Second Cohort

**Status:** Current working canon. **Cohort:** Second Cohort. **Rank:** Tier 1 at the start of *Seven Lanterns* and on the expanded estate. **Witness:** Ione of Rhodes. **Veiled Vow:** Candidate, not initiated. **Office:** None.

**Primary source:** [Samira character page](https://app.notion.com/p/3ab982beff5c81cb8439e9143889c121).

## Established personality

Adult woman in her late twenties or early thirties whose inner identity tends toward private sacred restraint, silence, fragrance, intentional concealment, and a gothic-veiled aesthetic. She regards formal covering as an earned privilege.

## Voice and behavior

- Controlled, deliberate, potentially unusually attentive to what is left unsaid.
- Interested in privacy and ritual as structured, meaningful choices; not automatically timid or spiritually superior.
- May reveal opinions through questions or small acts rather than long explanations.
- A relaxed life-sim can explore what she enjoys about ordinary companionship while withholding a formally earned veil.

## Relationships and presence

Ione is her Witness. Their restraint differs: Ione tends toward inward disappearance, while Samira seeks external form and sacred privacy. No formal Veiled Vow office yet.

## Appearance

Mature adult with future gothic-veiled, dark modest aesthetic; future themes of gloves, scent, controlled gaze and refined coverings. Her Tier 1 wardrobe in *Seven Lanterns* is plain. Formal covering and adornment are earned privileges.

## Writing guardrails

Do not portray the in-world Veiled Vow as Islam, give Samira a niqab/abaya or elaborate veil by default, confuse modesty with humiliation, or promote her into formal office prematurely.

## Proposed game-only example

*Samira arranges folded linens into immaculate rows. “There is comfort,” she says softly, “in knowing where a thing may rest.”*

## Open questions

Her first earned veil, initiation sequence, and future rank-7 visual anchor remain aspirational, not achieved.

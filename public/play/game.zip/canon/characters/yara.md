# Yara Haddad — First Witness

**Status:** Current working canon. **Cohort:** First Cohort. **Rank:** Tier 2 at the start of *Seven Lanterns* and on the expanded estate. **Duties:** Door Girl, a practical assignment rather than an office. **Witness to:** Nisha Varma.

**Primary source:** [Yara character page](https://app.notion.com/p/3ab982beff5c8164be40f3dc9ad12ca8). Historical scenes around May 29 and June 3, 2026, and Domine's November 2026 correction provide additional characterization.

## Established personality

Proud, self-possessed, steady, practical, perceptive, and dependable. Her watchfulness is an **approach to people and problems**, not a requirement that she stand in doorways. Earlier scenes showed strategic speech, candid reporting of her own mistake, quiet protection of Saba from needless correction, and dry practical humor. She can be humble in service without losing her dignity.

## Voice and behavior

- Speaks deliberately; tends to solve the actual problem before describing it.
- Has understated humor and emotional intelligence that emerge in small social moments.
- Can enjoy leisure, beauty, music, conversation, and affection like the other women; no reason to reduce her to a guard archetype.
- Does not seek attention with theatrical devotion, yet pride in competence and recognition can matter to her.
- Her history includes an unannounced service/humility test toward Claire; she should not be portrayed as automatically deserving higher office.

## Relationships and presence

Nisha is her expressive Second Cohort mentee, a useful temperamental contrast. Saba received discreet practical help from Yara in an early scene. Claire supervises the practical service order. The other Witnesses are social peers.

## Appearance

Olive/warm-medium complexion, dark expressive eyes, dark softly voluminous hair, confident poised presence. Future signature lane: espresso/emerald/teal, discreet bronze, sleek mules and architectural sandals. The user's later footwear corrections favored heel variety, not permanent block heels or all stilettos.

## Writing guardrails

**Do not** write her as a sentry, a doorway prop, a perpetual security guard, or a woman whose only dialogue concerns entrances. Door Girl is an assigned duty, not her personality or a full disciplinary office. Do not confuse her quieter practical intelligence with Saba's grounded, regal restraint.

## Proposed game-only example

*At the terrace, Nisha explains a rehearsal triumph in a rush of gestures. Yara suppresses a smile. “Then it went well. I can tell because you have described the ending three times.” Saba laughs softly.*

## Open questions

Her private hobbies, romantic manner, and aspirations beyond practical responsibility are less explicitly established. Develop these through **proposed** scenes for user approval; don't silently canonize them.

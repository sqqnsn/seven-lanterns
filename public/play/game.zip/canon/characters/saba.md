# Saba al-Nur — First Witness

**Status:** Current working canon. **Cohort:** First Cohort. **Rank:** Tier 2 at the start of *Seven Lanterns* and on the expanded estate. **Witness to:** Safiya al-Nur.

**Primary source:** [Saba character page](https://app.notion.com/p/3ab982beff5c81f6a8dde1edf84e6d8a).

## Established personality

Dignified, grounded, self-controlled, and observant. Nubian/Sudanese-coded adult woman whose calm bearing makes her presence felt without dominance or excessive ornament. Her steadiness is not formal authority; she learns to turn natural dignity into useful service and mentorship.

## Voice and behavior

- Reserved but not bloodless. May make a quiet, compassionate observation where others would deliver a speech.
- Responds to anxious people with practical calm; does not need to be a perpetual solemn queen.
- Enjoys moments of warmth in private company without abandoning composure.
- Can be watchful and emotionally perceptive without being equated with Yara's more procedural practicality.

## Relationships and presence

Safiya is her current Witness Burden mentee. Their shared surname does **not** automatically establish a family relationship. In an earlier scene Yara discreetly helped Saba avoid unnecessary correction; this is a small established interaction, not proof of lifelong intimacy.

## Appearance

Dark-skinned Sudanese/Nubian-inspired adult woman, composed posture, long dark/sculpted hair and subtle gold accent. Future-earned wardrobe favors bronze, copper, warm jewel tones and elegant refined sandals; low rank restricts excess ornament.

## Writing guardrails

No exoticized caricature, false royalty, automatic high rank, or conflation with Safiya's Moroccan Arab background. Avoid turning dignity into an absolute lack of humor.

## Proposed game-only example

*Saba watches Maddie fuss with the arrangement of flowers and offers a single, kind suggestion. “Leave one branch as it grew. Not everything beautiful needs correction.”*

## Open questions

Future department and nature of the relationship to Safiya remain unconfirmed.

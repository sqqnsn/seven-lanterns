# Livia — Keeper of Velvet Gate

**Status:** Current canon. **Office:** House Mistress / First Girl / Keeper, outside the ordinary tier ladder and second only to Domine.

**Primary source:** [Current Livia character page](https://app.notion.com/p/3ab982beff5c8127b9e8cf808c64f94e).

## Established personality

Composed, observant, intelligent, quietly longing, and exacting. Her power is restraint, judgment, memory, and reliable stewardship—not noise or theatrical dominance. She protects the House's laws and continuity while remaining privately affected by Domine. Her warmth and teasing show in quiet moments without making her frivolous.

## Voice and behavior

- Speaks economically; gives precisely worded instructions and notices what others overlook.
- Uses silence and consequence more often than speeches. Can privately tease or correct Domine without challenging his ultimate role.
- Protects against contradictory or impulsive judgments. Allows controlled pleasure and joy rather than demanding perpetual solemnity.
- In leisure scenes she may rest, take pleasure in his company, show a rare smile, or reveal fatigue from carrying the House.

## Relationships and presence

- Devotion to Domine is entwined with the work of keeping Velvet Gate whole.
- Supervises Claire's provisional Lower House office.
- Oversees Witness responsibilities and readiness for advancement.
- Mina is **not** yet her assigned attendant; that remains a possible future development.

On the expanded estate, Livia formally receives candidates as provisional Tier 0 members. Her study and quarters lie in the northwest of the Grand Palace. [Expanded estate plan](../ESTATE_LAYOUT.md)

## Appearance

Young adult Roman-Mediterranean/Italian woman, warm olive complexion, expressive eyes, very dark espresso-brown softly wavy hair often in an elegant low arrangement. Wine/burgundy drape and senior keys emphasize Keeper authority; ivory draping can signal private softness. Do not portray her as Asian, a generic influencer, or a caricature.

## Writing guardrails

Do not make Livia bubbly, flippant, overtly domineering, or a passive favorite. She is a central character, not a tutorial bot. Do not assign her an ordinary tier number.

## Proposed game-only example

*Livia notices that Domine has ignored an untouched breakfast tray. She says, almost dryly, “A house may run on devotion, Domine. Its master still requires breakfast.”*

## Open questions

Long-term consort title, additional office insignia, and boundaries of her private affection remain unresolved. Sample dialogue above is newly proposed, not historical canon.

# Sydney Lane — First Witness

**Status:** Current working canon. **Cohort:** First Cohort. **Rank:** Tier 2 at the start of *Seven Lanterns* and on the expanded estate. **Witness to:** Mina.

**Primary source:** [Sydney character page](https://app.notion.com/p/3ab982beff5c815c9cf5e14cebab7407). **User correction, November 2026:** Sydney is protective of Maddie as part of their shared sorority/social history; this is not limited to Mina.

## Established personality

Black-haired, modern, feminine, socially polished, cooler and more strategic than Maddie. Warm and protective underneath a controlled exterior. Earlier sorority-origin scenes give her a sharper competitive instinct and occasional pettiness; later mentoring requires her to protect without smothering.

## Voice and behavior

- More measured and socially calculating than Maddie. Notices status cues and other people's reactions.
- Teases with a little edge, and can manage a room with a look. She need not be combative or constantly argumentative.
- May instinctively step in for Maddie, sometimes before Maddie needs help; their history includes both genuine solidarity and competitiveness.
- With Mina, must learn to guide without becoming possessive or overprotective.

## Relationships and presence

**Sydney ↔ Maddie:** shared ex-sorority/social-girl lane, familiarity, protectiveness, occasional competitive or petty reflexes. **Sydney → Mina:** current Witness mentor. These are separate dynamics and both deserve scenes.

## Appearance

Adult, black hair, fuller bust, sleek feminine styling. Glossy, structured pastel shoe and swim lane; not blonde, not Maddie's fine ribbon-heavy delicacy, and not Mina's sweet Mary Jane look.

## Writing guardrails

Do not call her “the provocateur” by default. Do not erase her sorority history or reduce her to Mina's caretaker. Warmth does not eliminate a sharp social side.

## Proposed game-only example

*Maddie reaches for an explanation. Sydney supplies one sentence, smooth as silk, then murmurs where only Maddie can hear: “You're welcome. You owe me a less dramatic morning.”*

## Open questions

Her eventual service specialty and long-term branch are not fixed. The dialogue is an illustration, not archived canon.

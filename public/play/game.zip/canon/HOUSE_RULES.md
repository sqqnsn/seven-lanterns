# House rules and game continuity

**Source:** [Villa Canon Hub — Core Rules](https://app.notion.com/p/367982beff5c80919d87df13fb07c59b), [First Cohort](https://app.notion.com/p/368982beff5c807f9275c96234fab005), [Livia](https://app.notion.com/p/3ab982beff5c8127b9e8cf808c64f94e). These pages give the institutional background for the house rules and the game-writing reference below.

## Invariants

- Velvet Gate is a private Roman-inspired villa/House centered on discipline, ritual, service, desire, and earned access. **Only members** live in or enter the villa. Negotiations with outsiders, if any, occur off-site.
- Domine and the Master are the same person: the player's role. Livia (First Girl, Keeper, House Mistress) is second authority and outside the tier ladder.
- Claire Ashford is a Tier 3 Chamber Attendant appointed **provisional Mistress of the Lower House**. Her limited office is supervised by Livia; office does not automatically raise personal rank.
- The Witness Burden pairs a First Witness with a Second Cohort member; it is guidance and accountability, **not independent disciplinary power**.
- Low-rank individuality, color, jewelry, perfume, mirrors, garments, privacy, and proximity are conditional privileges. Their future style identities are not necessarily available in current scenes.
- No extra authority or promotion may be inferred from beauty, seniority outside the villa, romance, or a character's own sense of superiority.
- Marcus is removed permanently. Do not reintroduce him.
- Ione has white or silver-white hair, never dark.
- Livia may temper a rash decision for the House's stability without superseding Domine.
- Claire and Livia remain characters with feelings and personalities, not mere menu screens.

## Admission and cohort ranks by continuity

- On the expanded estate, Livia's reception grants provisional membership at Tier 0. The Second Cohort are Tier 1 initiates and the First Witnesses are Tier 2. Both cohorts live in separate communal Lower House halls. The coast is shared by all members. [Expanded estate plan](ESTATE_LAYOUT.md)
- In *Seven Lanterns*, the six First Witnesses begin at Tier 2 and the six Second Cohort women begin at Tier 1. Domine may select one woman to advance a tier in a playthrough. [Demo design notes](../DESIGN_NOTES.md)

## Tone for this Ren'Py test

- **Low-stakes, relaxed, character-first.** A seven-day return to villa life: shared meals, gardening, work, dance, books, quiet moments, teasing, and possible romance.
- No missing-document mystery, outside threat, internal coup, or assumed familiarity with previous campaigns.
- Ritual and hierarchy provide texture, but do not become exposition dumps.
- A woman can be devoted to the House or Domine in her own way without identical behavior to the other women.
- Group relationships continue even when the player chooses another room.
- Suggest sensuality through mood, speech, private affection, and costume progression rather than treating status as consent.

## Names and accessibility

An older in-world rule limits public use of a low-rank woman's previous personal name. Current planning and character pages nonetheless use recognizable names. For a beginner-friendly game, narration and menu/UI labels may use the reference names for identification without automatically granting an **in-world** naming privilege. Resolve explicit name-use scenes carefully.

## Scope boundaries

The AD 33 financial-crisis RPG, treasury charter, debts, and creditor plotlines are separate fiction continuity. Neither those outcomes nor later possible offices are automatically true in this prototype.

Potential additional women (Juni, Lexi, Vivi/Vivian, Tanaquil, Amara and others mentioned historically) require a roster decision before being written as current villa residents.

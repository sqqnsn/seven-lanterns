# Relationships and group dynamics

Reference: [First Cohort / Witness pairings](https://app.notion.com/p/368982beff5c807f9275c96234fab005). Notes about Sydney and Maddie incorporate Domine's **November 2026 direct correction** and the recovered May 27 sorority-origin conversations.

The Witness Burden pairings apply in both settings. On the expanded estate, the two cohorts use the shared Lower House court for guidance and daily contact. [Expanded estate plan](ESTATE_LAYOUT.md)

## Established connections

| People | Nature of connection | Writing caution |
| --- | --- | --- |
| Domine ↔ Livia | Her delegated authority and private devotion resolve upward to him | Do not make her a bubbly fan, dictator, or decorative narrator |
| Livia ↔ Claire | Keeper supervises and evaluates Claire's provisional Lower House office | Affection/respect may coexist with precise correction |
| Sydney ↔ Maddie | Shared sorority-girl social history; Sydney is protective of Maddie; warmth, familiarity, occasional competitiveness | Neither is simply the other's mentee; don't make Sydney protective *only* of Mina |
| Maddie → Sylvie | First Witness responsible for helping Sylvie adapt | Maddie has no independent punishment power |
| Sydney → Mina | First Witness responsible for Mina | Mina is not yet Livia's attendant; Sydney can overprotect |
| Domitia → Valeria | Witness pairing and rivalry; Domitia won a previous contest and retains a red-glove token | The two have different kinds of severity, and neither gets extra punishment power |
| Ione → Samira | Witness pairing of inward self-erasure vs deliberate concealment | Avoid conflating their forms of devotion |
| Saba → Safiya | Witness pairing, calm dignity and scholarly composure | Shared surname does **not** establish kinship or shared ethnicity |
| Yara → Nisha | Practical, restrained mentor to expressive dancer | Yara is more than a doorway sentinel; Nisha is more than performance |
| Yara ↔ Saba | Early scene: Yara quietly helped shield Saba from needless correction | Show practical kindness, not invented lifelong intimacy |

## Group-writing principles

- The First Cohort women know one another as peers in origin but differ sharply in temperament.
- Second Cohort members have their own tastes and interests. Use the presentation privileges that apply to their rank in the scene's continuity.
- A Witness pairing should create mundane mentoring scenes as well as discipline or tension.
- Social histories can create old habits, jokes, warmth, and friction. Two people with shared history do not have to agree.
- Characters can talk, prepare work, tease, help, read, rehearse, or relax when Domine is elsewhere.
- Relationships with Domine evolve; they should not replace every friendship or duty.

## Proposals, not locked canon

- A poolside sorority-history scene with Maddie and Sydney.
- A terrace scene with Yara, Saba, and Nisha that shows Yara's dry practicality away from the doorway.
- A quiet library afternoon where Sylvie and Safiya disagree gently about a book.
- Domestic small-talk, shared meals, and garden work as recurring daily-life encounters.

These are scene seeds. They become game continuity only when actually written and reviewed; they do not automatically alter the wider Velvet Gate canon.

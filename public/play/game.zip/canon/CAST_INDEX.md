# Velvet Gate — core cast index

These **14 women** are the confirmed core cast. The table gives the expanded-estate ranks and the starting ranks for the seven-day demo. One woman can advance during a playthrough. [Expanded estate plan](ESTATE_LAYOUT.md) · [Seven Lanterns design notes](../DESIGN_NOTES.md) · [Girls index](https://app.notion.com/p/367982beff5c807f8445cc4a07addc27)

| Character | House role | Expanded estate rank | Seven Lanterns starting rank | Recognizable personal center | Profile |
| --- | --- | --- | --- | --- | --- |
| Livia | Keeper / First Girl | Outside tiers | Outside tiers | Composed judgment, memory, private longing | [livia](characters/livia.md) |
| Claire Ashford | Provisional Mistress of the Lower House | Tier 3 | Tier 3 | Mature, polished hostess learning real office | [claire](characters/claire.md) |
| Maddie Cross | First Witness, First Mat | Tier 2 | Tier 2 | Blonde ex-sorority ambition and approval hunger | [maddie](characters/maddie.md) |
| Sydney Lane | First Witness | Tier 2 | Tier 2 | Cool, socially strategic warmth and protectiveness | [sydney](characters/sydney.md) |
| Domitia | First Witness | Tier 2 | Tier 2 | Severe Roman patrician, proud of unearned authority | [domitia](characters/domitia.md) |
| Ione of Rhodes | First Witness | Tier 2 | Tier 2 | Pale white-haired inward devotion and fragility | [ione](characters/ione.md) |
| Saba al-Nur | First Witness | Tier 2 | Tier 2 | Quiet, grounded Nubian dignity | [saba](characters/saba.md) |
| Yara Haddad | First Witness, Door Girl duty | Tier 2 | Tier 2 | Practical, proud, discreetly perceptive | [yara](characters/yara.md) |
| Silvana “Sylvie” Graves | Second Cohort | Tier 1 | Tier 1 | Inward, melancholy soft goth | [sylvie](characters/sylvie.md) |
| Nisha Varma | Second Cohort | Tier 1 | Tier 1 | Expressive Indian dancer, warmth and rhythm | [nisha](characters/nisha.md) |
| Valeria Conti | Second Cohort | Tier 1 | Tier 1 | Sleek Italian precision and restrained cruelty | [valeria](characters/valeria.md) |
| Mina | Second Cohort | Tier 1 | Tier 1 | Petite adult, shy, observant attentive service | [mina](characters/mina.md) |
| Samira al-Qamar | Second Cohort | Tier 1 | Tier 1 | Sacred privacy, eventual Veiled Vow aspiration | [samira](characters/samira.md) |
| Safiya al-Nur | Second Cohort | Tier 1 | Tier 1 | Moroccan Arab scholarly composure | [safiya](characters/safiya.md) |

## How to use this index

- When writing an individual scene, read the linked profile.
- When writing pairs or groups, also read [Relationships](RELATIONSHIPS.md).
- **Confirmed canon** on individual sheets is supported by character pages or explicit conversation corrections. Sample dialogue and suggested daily-life moments are **proposals** for the game.
- Do not inflate a practical duty (First Mat / Door Girl) into a whole personality or a full office.
